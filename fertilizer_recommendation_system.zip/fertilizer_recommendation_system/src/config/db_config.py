# SQLite config (local file)
DB_PATH = "data/fertilizer.db"
