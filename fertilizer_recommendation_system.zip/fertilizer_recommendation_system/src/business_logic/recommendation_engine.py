class RecommendationEngine:
    """Simple rule-based fertilizer recommender.
    You can extend this with ML models or more complex rules.
    """
    def recommend(self, n, p, k, ph, crop):
        # Basic rules (example): tweak thresholds for your domain
        try:
            if n is None or p is None or k is None:
                return "Insufficient data"
            if n < 40:
                return "Urea (Nitrogen supplement)"
            if p < 30:
                return "DAP (Phosphorus supplement)"
            if k < 90:
                return "MOP (Potassium supplement)"
            if ph < 5.5:
                return "Apply Lime to raise pH"
            if ph > 8.0:
                return "Apply Sulfur to lower pH"
            return "Balanced NPK 20:20:20"
        except Exception:
            return "Error in rule evaluation"
