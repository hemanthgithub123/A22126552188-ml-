# Placeholder for domain models if you want to use dataclasses later
from dataclasses import dataclass

@dataclass
class SoilSample:
    nitrogen: float
    phosphorus: float
    potassium: float
    ph: float
    crop: str
