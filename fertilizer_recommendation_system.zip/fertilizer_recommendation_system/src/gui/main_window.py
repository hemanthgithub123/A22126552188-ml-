import tkinter as tk
import tkinter.font as tkfont
from tkinter import messagebox, ttk
from src.business_logic.recommendation_engine import RecommendationEngine
from src.data_access.db_manager import DBManager


class FertilizerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Fertilizer Recommendation System")
        # Start in fullscreen for an immersive experience. Use F11 to toggle.
        self._is_fullscreen = True
        try:
            # Most platforms: fullscreen attribute
            self.root.attributes("-fullscreen", True)
        except Exception:
            # Fallback to maximized window state on platforms that don't support attributes
            try:
                self.root.state('zoomed')
            except Exception:
                # leave default geometry as last resort
                pass

        self.engine = RecommendationEngine()
        self.db = DBManager()

        # UI fonts and sizing
        self._title_font = ("Arial", 14, "bold")
        self._label_font = ("Segoe UI", 10)
        self._result_font = ("Arial", 12, "bold")

        # Prepare resize debounce id before building UI so _schedule_resize can reference it
        self._resize_after_id = None

        self._build_ui()

        # Bind keys for toggle fullscreen and escape to exit
        self.root.bind("<F11>", lambda e: self._toggle_fullscreen())
        self.root.bind("<Escape>", lambda e: self._exit_fullscreen())
        # Keep columns responsive on resize
        self.root.bind("<Configure>", lambda e: self._schedule_resize())

    def _build_ui(self):
        frame = tk.Frame(self.root, padx=12, pady=12)
        frame.pack(fill=tk.BOTH, expand=True)
        # Allow grid expansion
        frame.columnconfigure(1, weight=1)
        frame.rowconfigure(8, weight=1)  # treeview row

        # Input fields
        labels = [
            ("Nitrogen (N)", "nitrogen"),
            ("Phosphorus (P)", "phosphorus"),
            ("Potassium (K)", "potassium"),
            ("pH", "ph"),
            ("Crop", "crop"),
        ]
        self.entries = {}
        for i, (lab, key) in enumerate(labels):
            tk.Label(frame, text=lab).grid(row=i, column=0, sticky="w", pady=6)
            ent = tk.Entry(frame)
            ent.grid(row=i, column=1, sticky="we", padx=6, pady=4)
            self.entries[key] = ent

        # Buttons
        btn_frame = tk.Frame(frame)
        btn_frame.grid(row=6, column=0, columnspan=2, pady=12)
        tk.Button(btn_frame, text="Get Recommendation", command=self.on_recommend).grid(row=0, column=0, padx=6)
        tk.Button(btn_frame, text="View History", command=self.on_view_history).grid(row=0, column=1, padx=6)
        tk.Button(btn_frame, text="Clear", command=self.on_clear).grid(row=0, column=2, padx=6)
        tk.Button(btn_frame, text="Clear Saved History", command=self._clear_saved_history).grid(row=0, column=3, padx=6)

        # Result label
        self.result_var = tk.StringVar(value="")
        tk.Label(frame, textvariable=self.result_var, font=self._result_font, fg="blue").grid(row=7, column=0, columnspan=2, pady=8)

        # History treeview
        # Treeview should expand to fill available space
        style = ttk.Style()
        try:
            style.theme_use('default')
        except Exception:
            pass
        # Heading and row styling for readability
        style.configure("Treeview.Heading", font=self._title_font)
        style.configure("Treeview", font=("Segoe UI", 10), rowheight=24)

        self.tree = ttk.Treeview(frame, columns=("id", "n", "p", "k", "ph", "crop", "fert", "created"), show="headings")

        # Use full, descriptive column headers
        columns_info = [
            ("id", "ID"),
            ("n", "Nitrogen (N)"),
            ("p", "Phosphorus (P)"),
            ("k", "Potassium (K)"),
            ("ph", "pH"),
            ("crop", "Crop"),
            ("fert", "Recommended Fertilizer"),
            ("created", "Created At"),
        ]
        for col, head in columns_info:
            # Make headings clickable for sorting
            self.tree.heading(col, text=head, command=lambda c=col: self._on_heading_click(c))

        # Initial widths - will be updated proportionally on resize
        initial_total = 900
        weights = {
            "id": 0.06,
            "n": 0.11,
            "p": 0.11,
            "k": 0.11,
            "ph": 0.07,
            "crop": 0.18,
            "fert": 0.26,
            "created": 0.10,
        }
        for c in ("id", "n", "p", "k", "ph", "crop", "fert", "created"):
            w = max(60, int(initial_total * weights.get(c, 0.1)))
            # Align numeric columns to center; text columns to left for readability
            anchor = "center" if c in ("id", "n", "p", "k", "ph", "created") else "w"
            self.tree.column(c, width=w, anchor=anchor)

        self.tree.grid(row=8, column=0, columnspan=2, sticky="nsew", pady=6)

        # Add a vertical scrollbar
        vsb = ttk.Scrollbar(frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        vsb.grid(row=8, column=2, sticky='ns')

        # Alternating row colors to make columns visually separable (simulates gridlines)
        self.tree.tag_configure('odd', background='#ffffff')
        self.tree.tag_configure('even', background='#f6f6f6')

        # refresh initial history and size columns
        self._refresh_history()
        self._schedule_resize(immediate=True)
        # track sort state per column (False == ascending next click)
        self._sort_states = {}

    def _toggle_fullscreen(self):
        self._is_fullscreen = not self._is_fullscreen
        try:
            self.root.attributes("-fullscreen", self._is_fullscreen)
        except Exception:
            if self._is_fullscreen:
                try:
                    self.root.state('zoomed')
                except Exception:
                    pass
            else:
                try:
                    self.root.state('normal')
                except Exception:
                    pass

    def _exit_fullscreen(self):
        self._is_fullscreen = False
        try:
            self.root.attributes("-fullscreen", False)
        except Exception:
            try:
                self.root.state('normal')
            except Exception:
                pass

    def _schedule_resize(self, immediate: bool = False):
        # Debounce frequent configure events
        if self._resize_after_id:
            try:
                self.root.after_cancel(self._resize_after_id)
            except Exception:
                pass
        delay = 50 if not immediate else 5
        self._resize_after_id = self.root.after(delay, self._on_resize)

    def _on_resize(self):
        # Auto-adjust column widths based on available tree width
        try:
            total = max(self.tree.winfo_width(), 300)
            # Use weighted proportions so Crop and Fertilizer get more space
            weights = {
                "id": 0.06,
                "n": 0.11,
                "p": 0.11,
                "k": 0.11,
                "ph": 0.07,
                "crop": 0.18,
                "fert": 0.26,
                "created": 0.10,
            }
            # Normalize weights (in case they don't sum to 1 exactly)
            s = sum(weights.values())
            for col, w in weights.items():
                frac = w / s
                self.tree.column(col, width=max(50, int(total * frac)))
        except Exception:
            pass

    def _on_heading_click(self, col: str):
        """Sort the treeview by the given column. Toggles ascending/descending."""
        # Toggle sort state
        current = self._sort_states.get(col, False)
        # new state: True means descending, False means ascending
        new_desc = not current
        self._sort_states[col] = new_desc

        # Collect current rows
        rows = []
        for item in self.tree.get_children():
            cell = self.tree.set(item, col)
            vals = self.tree.item(item)['values']
            rows.append((cell, vals))

        def _key(t):
            v = t[0]
            if v is None:
                return ""
            # try numeric
            try:
                return float(v)
            except Exception:
                return str(v).lower()

        rows.sort(key=_key, reverse=new_desc)

        # Re-insert rows in sorted order and reapply alternating tags
        for i, (_, vals) in enumerate(rows):
            tag = 'even' if i % 2 == 0 else 'odd'
            # remove existing items in order and reinsert
        # Clear tree and insert in new order
        for itm in self.tree.get_children():
            self.tree.delete(itm)
        for i, (_, vals) in enumerate(rows):
            tag = 'even' if i % 2 == 0 else 'odd'
            self.tree.insert('', tk.END, values=vals, tags=(tag,))
        try:
            self._autofit_columns()
        except Exception:
            pass

    def _parse_inputs(self):
        try:
            n = float(self.entries["nitrogen"].get())
            p = float(self.entries["phosphorus"].get())
            k = float(self.entries["potassium"].get())
            ph = float(self.entries["ph"].get())
            crop = self.entries["crop"].get().strip() or "Unknown"
            return n, p, k, ph, crop
        except ValueError:
            raise ValueError("Please enter valid numeric values for N, P, K and pH.")

    def on_recommend(self):
        try:
            n, p, k, ph, crop = self._parse_inputs()
            fert = self.engine.recommend(n, p, k, ph, crop)
            self.db.insert_soil_data(n, p, k, ph, crop, fert)
            self.result_var.set(f"Recommendation: {fert}")
            self._refresh_history()
            messagebox.showinfo("Recommendation", f"Recommended: {fert}")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _refresh_history(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        data = self.db.fetch_all()
        # Ensure data is ordered by id (ascending). Convert id to int when possible.
        def _id_val(rec):
            try:
                return int(rec.get("id") or 0)
            except Exception:
                return 0

        data_sorted = sorted(data or [], key=_id_val)
        for idx, r in enumerate(data_sorted):
            tag = 'even' if idx % 2 == 0 else 'odd'
            vals = (
                r.get("id"),
                r.get("nitrogen"),
                r.get("phosphorus"),
                r.get("potassium"),
                r.get("ph"),
                r.get("crop"),
                r.get("recommended_fertilizer"),
                r.get("created_at"),
            )
            self.tree.insert("", tk.END, values=vals, tags=(tag,))
        # Auto-fit columns to content for a cleaner layout
        try:
            self._autofit_columns()
        except Exception:
            pass

    def on_view_history(self):
        self._refresh_history()
        messagebox.showinfo("History", "History refreshed.")

    def on_clear(self):
        for e in self.entries.values():
            e.delete(0, tk.END)
        self.result_var.set("")

    def _clear_saved_history(self):
        if not messagebox.askyesno("Confirm", "Clear all saved history? This cannot be undone."):
            return
        # Attempt to backup the DB before clearing
        try:
            backup_path = self.db.backup_db()
        except Exception as be:
            # If backup fails, ask the user whether to proceed without a backup
            proceed = messagebox.askyesno("Backup failed", f"Backup failed: {be}\nProceed to clear history without a backup?")
            if not proceed:
                return
            backup_path = None

        try:
            self.db.clear_history()
            self._refresh_history()
            msg = "All saved history has been removed."
            if backup_path:
                msg += f" Backup saved to: {backup_path}"
            messagebox.showinfo("Cleared", msg)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to clear history: {e}")

    def _autofit_columns(self, padding: int = 16, min_width: int = 50):
        """Adjust column widths to fit content and header text."""
        font = tkfont.Font(family="Segoe UI", size=10)
        # Measure header widths
        for col, head in [("id", "ID"), ("n", "Nitrogen (N)"), ("p", "Phosphorus (P)"), ("k", "Potassium (K)"), ("ph", "pH"), ("crop", "Crop"), ("fert", "Recommended Fertilizer"), ("created", "Created At")]:
            max_w = font.measure(str(head))
            # Measure cell texts
            for item in self.tree.get_children():
                cell = self.tree.set(item, col)
                if cell is None:
                    cell = ""
                w = font.measure(str(cell))
                if w > max_w:
                    max_w = w
            self.tree.column(col, width=max(min_width, max_w + padding))

    def __del__(self):
        try:
            self.db.close()
        except:
            pass
