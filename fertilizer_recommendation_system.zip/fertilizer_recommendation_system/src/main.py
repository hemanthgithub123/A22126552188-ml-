from src.gui.main_window import FertilizerApp
import tkinter as tk
import os

if __name__ == "__main__":
    # Ensure data directory exists
    os.makedirs("data", exist_ok=True)
    root = tk.Tk()
    app = FertilizerApp(root)
    root.mainloop()
