# kept for compatibility; main DBManager exposes methods
