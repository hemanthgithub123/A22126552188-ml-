import sqlite3
from src.config.db_config import DB_PATH
import os
import shutil
from datetime import datetime

class DBManager:
    def __init__(self):
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        self.conn = sqlite3.connect(DB_PATH, timeout=10)
        self.conn.row_factory = sqlite3.Row
        self.cursor = self.conn.cursor()
        self._ensure_tables()

    def _ensure_tables(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS soil_data (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nitrogen REAL,
                phosphorus REAL,
                potassium REAL,
                ph REAL,
                crop TEXT,
                recommended_fertilizer TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
        ''')
        self.conn.commit()

    def insert_soil_data(self, n, p, k, ph, crop, fertilizer):
        self.cursor.execute('''
            INSERT INTO soil_data (nitrogen, phosphorus, potassium, ph, crop, recommended_fertilizer)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (n, p, k, ph, crop, fertilizer))
        self.conn.commit()
        return self.cursor.lastrowid

    def fetch_all(self):
        self.cursor.execute('SELECT * FROM soil_data ORDER BY created_at DESC')
        return [dict(row) for row in self.cursor.fetchall()]

    def clear_history(self):
        """Delete all saved soil_data history."""
        self.cursor.execute('DELETE FROM soil_data')
        self.conn.commit()

    def backup_db(self, dest_dir: str = None) -> str:
        """Create a timestamped backup copy of the database file.

        Returns the backup file path on success. Raises an exception on failure.
        """
        src = DB_PATH
        if not os.path.exists(src):
            raise FileNotFoundError(f"Database file not found: {src}")

        # Default backup directory is the same folder as DB_PATH (usually data/)
        base_dir = os.path.dirname(src) or "."
        dest_dir = dest_dir or base_dir
        os.makedirs(dest_dir, exist_ok=True)

        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        base_name = os.path.splitext(os.path.basename(src))[0]
        backup_name = f"{base_name}_backup_{ts}.db"
        backup_path = os.path.join(dest_dir, backup_name)

        shutil.copy2(src, backup_path)
        return backup_path

    def close(self):
        try:
            self.cursor.close()
        except:
            pass
        try:
            self.conn.close()
        except:
            pass
