# Fertilizer Recommendation System (Offline, SQLite)

This is a simple desktop application built with Python and Tkinter that gives fertilizer
recommendations based on basic soil parameters. It uses SQLite as a local embedded database,
so it runs fully offline with no external DB setup required.

## How to run (Windows / macOS / Linux)
1. Make sure you have Python 3.9+ installed.
2. Open a terminal in the project root.
3. (Optional) Create and activate a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate   # macOS/Linux
   venv\Scripts\activate    # Windows
   ```
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. Run the app (recommended):
   ```bash
   python -m src.main
   ```

If you run into a "ModuleNotFoundError: No module named 'src...'" when using `python src/main.py`, prefer the `-m` form above or ensure the project root is on your PYTHONPATH. You can also run `src/main.py` directly if you execute it from the `src` directory (so `gui` and other modules are importable).

## Notes
- The app stores data in `data/fertilizer.db`.
- To create a single executable for Windows: use PyInstaller:
   ```bash
   pyinstaller --onefile --windowed -n fertilizer_app -F -w -p src src/main.py
   ```
