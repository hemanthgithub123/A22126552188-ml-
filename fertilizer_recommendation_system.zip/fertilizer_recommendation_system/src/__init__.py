# package marker for src
# This file makes `src` a package so `python -m src.main` works reliably.
